<?php
// Ultra simple test - just output text
echo "PHP is working! Time: " . date('Y-m-d H:i:s');
?>







